// Quan ly access_token / refresh_token cua Zalo OA.
// Access token cua Zalo OA het han sau ~25 gio, refresh_token dung 1 lan roi doi moi.
// File nay luu token vao tokens.json de ton tai qua nhung lan restart server,
// va tu dong lam moi truoc khi het han.

const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const TOKENS_FILE = path.join(__dirname, 'tokens.json');
const REFRESH_URL = 'https://oauth.zaloapp.com/v4/oa/access_token';

function loadTokens() {
  if (fs.existsSync(TOKENS_FILE)) {
    return JSON.parse(fs.readFileSync(TOKENS_FILE, 'utf8'));
  }
  // Lan dau chay: seed tu .env
  const seed = {
    access_token: process.env.ZALO_INITIAL_ACCESS_TOKEN || '',
    refresh_token: process.env.ZALO_INITIAL_REFRESH_TOKEN || '',
    updated_at: 0
  };
  saveTokens(seed);
  return seed;
}

function saveTokens(tokens) {
  fs.writeFileSync(TOKENS_FILE, JSON.stringify(tokens, null, 2));
}

let current = loadTokens();

async function refreshAccessToken() {
  if (!current.refresh_token) {
    console.warn('[token-manager] Chua co refresh_token, dang dung access_token ban dau.');
    return current.access_token;
  }
  const params = new URLSearchParams({
    refresh_token: current.refresh_token,
    app_id: process.env.ZALO_APP_ID,
    grant_type: 'refresh_token'
  });

  const res = await fetch(REFRESH_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      secret_key: process.env.ZALO_APP_SECRET
    },
    body: params
  });
  const data = await res.json();

  if (data.access_token) {
    current = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || current.refresh_token,
      updated_at: Date.now()
    };
    saveTokens(current);
    console.log('[token-manager] Da lam moi access_token luc', new Date().toISOString());
  } else {
    console.error('[token-manager] Lam moi token that bai:', data);
  }
  return current.access_token;
}

function getAccessToken() {
  return current.access_token;
}

// Lam moi dinh ky moi 20 gio (truoc khi het han 25 gio)
function startAutoRefresh() {
  refreshAccessToken().catch(console.error);
  setInterval(() => {
    refreshAccessToken().catch(console.error);
  }, 20 * 60 * 60 * 1000);
}

module.exports = { getAccessToken, refreshAccessToken, startAutoRefresh };
