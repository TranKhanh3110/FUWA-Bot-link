// Logic loi cua bot: tim kiem cuc bo + hoi Claude de chon dung link.
// Tach rieng file nay de dung chung cho ca server.js (webhook that) va test.js (test dong lenh).

const fetch = require('node-fetch');
const DATA = require('./data');

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY;

function normalize(str) {
  return (str || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd')
    .trim();
}

function localMatch(query, limit) {
  const q = normalize(query);
  const terms = q.split(/\s+/).filter(Boolean);
  if (terms.length === 0) return [];
  const totalWeight = terms.reduce((sum, t) => sum + t.length, 0);

  const scored = DATA.map(item => {
    const hay = normalize(`${item.layer1} ${item.layer2} ${item.name}`);
    let score = 0;
    terms.forEach(t => { if (hay.includes(t)) score += t.length; });
    if (hay.includes(q) && q.length > 2) score += q.length * 1.5; // thuong khi khop nguyen cum
    return { item, score };
  })
    // chi giu ung vien khop du manh (>=50% trong so tu khoa), tranh gui context nhieu cho Claude
    .filter(s => s.score > 0 && (s.score / totalWeight) >= 0.5)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map(s => s.item);
  return scored;
}

async function askClaude(userText, { hotline } = {}) {
  let candidates = localMatch(userText, 20);
  if (candidates.length < 5) candidates = DATA;

  const catalog = candidates
    .map((it, i) => `${i + 1}. [${it.layer1} › ${it.layer2}] ${it.name} — LINK:${it.link}`)
    .join('\n');

  const systemPrompt = `Ban la tro ly noi bo cua cong ty FUWA3e tren Zalo, giup khach/nhan vien nhanh chong tim DUNG link tai lieu, hinh anh, logo, catalogue, chung nhan... trong kho Drive noi bo.

QUY TAC BAT BUOC:
- CHI duoc chon link tu DANH SACH ben duoi. Tuyet doi khong tu bia link hay tu suy dien URL khac.
- Neu khong co muc nao phu hop, noi ro la chua tim thay va goi y nguoi dung mo ta cu the hon (dong san pham Homecare/CarFresh/Babycare, hoac loai tai lieu: logo, anh, catalogue, video, bang gia...).
- Tra loi ngan gon, than thien, bang tieng Viet, xung "minh".
- Tin nhan Zalo la van ban thuan (khong markdown). Neu can liet ke, dung dau "-" va xuong dong.
- CHI tra ve JSON thuan, khong code fence, dung schema:
{"reply": "cau tra loi ngan", "items": [{"name": "...", "link": "..."}]}
- "items" toi da 5 muc phu hop nhat, co the la mang rong neu khong tim thay.

DANH SACH TAI LIEU:
${catalog}`;

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01'
    },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: 'user', content: userText }]
    })
  });

  const data = await response.json();
  if (data.error) {
    throw new Error(`Anthropic API error: ${data.error.message || JSON.stringify(data.error)}`);
  }

  const text = (data.content || [])
    .filter(b => b.type === 'text')
    .map(b => b.text)
    .join('\n')
    .trim()
    .replace(/^```json/i, '')
    .replace(/^```/, '')
    .replace(/```$/, '')
    .trim();

  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch (e) {
    console.error('[askClaude] Khong parse duoc JSON:', text);
    parsed = { reply: 'Xin lỗi, mình chưa xử lý được câu hỏi này, bạn thử hỏi lại rõ hơn nhé.', items: [] };
  }

  if (!parsed.items || parsed.items.length === 0) {
    const hotlineText = hotline || '(điền số hotline CSKH của FUWA3e ở đây)';
    parsed.reply = (parsed.reply || '') +
      `\n\nNếu cần hỗ trợ thêm, bạn có thể liên hệ hotline ${hotlineText} hoặc để lại câu hỏi, nhân viên sẽ phản hồi sớm nhất.`;
  }
  return parsed;
}

module.exports = { normalize, localMatch, askClaude };
