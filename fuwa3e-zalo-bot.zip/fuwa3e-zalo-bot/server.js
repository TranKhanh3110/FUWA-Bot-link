require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const crypto = require('crypto');
const { askClaude } = require('./bot-core');
const { getAccessToken, startAutoRefresh } = require('./token-manager');

const app = express();
app.use(express.json());

const ZALO_SEND_URL = 'https://openapi.zalo.me/v3.0/oa/message/cs';
const HOTLINE = process.env.FALLBACK_HOTLINE;

// ---------- Gui tin nhan tra loi qua Zalo OA ----------
async function sendZaloMessage(userId, reply, items) {
  let text = reply || '';
  if (items && items.length) {
    text += '\n\n' + items.map(it => `📁 ${it.name}\n${it.link}`).join('\n\n');
  }

  const res = await fetch(ZALO_SEND_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      access_token: getAccessToken()
    },
    body: JSON.stringify({
      recipient: { user_id: userId },
      message: { text }
    })
  });
  const data = await res.json();
  if (data.error) {
    console.error('[sendZaloMessage] Zalo tra ve loi:', data);
  }
  return data;
}

// ---------- Xac minh chu ky webhook cua Zalo (khuyen nghi bat trong production) ----------
function isValidZaloSignature(req) {
  const secretKey = process.env.ZALO_APP_SECRET_KEY_FOR_SIGNATURE;
  if (!secretKey) return true; // bo qua neu chua cau hinh (chi de test nhanh)
  const mac = req.headers['x-zevent-signature'];
  if (!mac) return false;
  const raw = JSON.stringify(req.body);
  const expected = crypto.createHmac('sha256', secretKey).update(raw).digest('hex');
  return mac === expected;
}

// ---------- Webhook ----------
app.get('/webhook', (req, res) => res.send('FUWA3e Zalo bot webhook is running'));

app.post('/webhook', async (req, res) => {
  res.sendStatus(200); // ack ngay de Zalo khong gui lai

  if (!isValidZaloSignature(req)) {
    console.warn('[webhook] Chu ky khong hop le, bo qua request.');
    return;
  }

  const event = req.body;
  if (event.event_name === 'user_send_text') {
    const userId = event.sender.id;
    const text = event.message && event.message.text;
    if (!text) return;

    try {
      const result = await askClaude(text, { hotline: HOTLINE });
      await sendZaloMessage(userId, result.reply, result.items);
    } catch (err) {
      console.error('[webhook] Loi xu ly:', err);
      await sendZaloMessage(userId, 'Xin lỗi, hệ thống đang gặp sự cố, bạn thử lại sau ít phút nhé.', []);
    }
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`FUWA3e Zalo bot dang chay tren cong ${PORT}`);
  startAutoRefresh();
});
