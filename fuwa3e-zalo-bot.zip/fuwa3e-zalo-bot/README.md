# FUWA3e Zalo Bot

Chatbot chạy trên **Zalo Official Account**, tự động gửi link tài liệu / hình ảnh / logo / catalogue / chứng nhận sản phẩm FUWA3e (dữ liệu lấy từ Google Drive nội bộ, file `data.js`).

Cách hoạt động: Zalo gửi tin nhắn của khách đến webhook của bạn → server rút gọn danh sách link liên quan → hỏi Claude để chọn đúng link (Claude **chỉ được chọn trong danh sách thật**, không tự bịa) → gửi trả lời lại cho khách qua Zalo.

---

## 1. Chuẩn bị trên Zalo Developers

1. Vào https://developers.zalo.me → đăng nhập bằng tài khoản quản trị OA của FUWA3e.
2. Tạo (hoặc chọn) **App** gắn với OA của công ty.
3. Vào mục **Official Account API** → lấy `App ID` và `App Secret`.
4. Vào mục cấp quyền OAuth để lấy **access_token** và **refresh_token** lần đầu (Zalo yêu cầu chủ OA đăng nhập xác nhận quyền 1 lần).
5. Vào mục **Webhook**:
   - Điền URL webhook: `https://<domain-cua-ban>/webhook`
   - Lấy **Secret Key** dùng để xác minh chữ ký (điền vào `ZALO_APP_SECRET_KEY_FOR_SIGNATURE`)
   - Bật sự kiện **User Send Text Message**

> Toàn bộ bước này nằm trong khu vực quản trị của Zalo, không AI nào (kể cả Claude) có thể tự thực hiện thay bạn vì cần xác thực danh tính chủ OA.

## 2. Cấu hình project

```bash
cp .env.example .env
```

Điền vào `.env`:
```
ZALO_APP_ID=...
ZALO_APP_SECRET=...
ZALO_INITIAL_ACCESS_TOKEN=...
ZALO_INITIAL_REFRESH_TOKEN=...
ZALO_APP_SECRET_KEY_FOR_SIGNATURE=...
ANTHROPIC_API_KEY=...     # lấy tại https://console.anthropic.com
PORT=3000
```

## 3. Test logic của bot ngay (KHÔNG cần chờ tài khoản Zalo)

Đây là phần bạn có thể làm ngay bây giờ, trong khi chờ được cấp quyền Zalo Developer:

```bash
npm install
cp .env.example .env
```

Chỉ cần điền `ANTHROPIC_API_KEY` trong `.env` (lấy tại https://console.anthropic.com), rồi chạy:

```bash
npm test
```

Chế độ hỏi liên tục ngay trong terminal, hoặc test 1 câu:

```bash
node test.js "cho tôi ảnh sản phẩm CarFresh"
```

Bot sẽ trả lời và liệt kê link — đúng logic y hệt khi chạy thật trên Zalo, chỉ khác là chưa gửi qua Zalo mà thôi. Dùng bước này để kiểm tra dữ liệu, tinh chỉnh câu trả lời trước khi đấu nối Zalo thật.

## 4. Cài đặt & chạy thử webhook thật

```bash
npm install
npm start
```

Server sẽ chạy tại `http://localhost:3000`. Để Zalo gọi được vào máy bạn khi test local, dùng `ngrok`:

```bash
ngrok http 3000
```

rồi dán URL ngrok (dạng `https://xxxx.ngrok-free.app/webhook`) vào ô Webhook trên Zalo Developers.

## 5. Triển khai thật (production)

Deploy `server.js` lên một server có domain HTTPS cố định, ví dụ:
- Railway / Render (dễ nhất, có gói miễn phí)
- VPS riêng (dùng PM2 để giữ tiến trình chạy: `pm2 start server.js`)

Sau khi có domain thật, cập nhật lại URL webhook trên Zalo Developers.

## 6. Cập nhật dữ liệu sản phẩm

Danh sách link nằm trong `data.js`, mỗi mục có dạng:

```js
{ layer1: "1. Branding", layer2: "Logo (PNG, SVG, JPG)", name: "1. Fuwa3e - Enzyme Cleaner", link: "https://drive.google.com/..." }
```

Khi Drive cập nhật thêm link mới, chỉ cần thêm object mới vào mảng này rồi deploy lại — không cần sửa logic bot.

## 7. Xử lý khi bot không tìm thấy câu trả lời

Nếu không có tài liệu nào khớp, bot sẽ tự động kèm thêm câu nhắc liên hệ hotline (điền số ở biến `FALLBACK_HOTLINE` trong `.env`). Nếu để trống, bot sẽ hiện dòng nhắc chung chung — nên điền số thật trước khi go-live để khách không rơi vào ngõ cụt.

## 8. Giới hạn cần lưu ý

- Access token Zalo OA hết hạn ~25h, `token-manager.js` đã tự động làm mới định kỳ (cần `refresh_token` hợp lệ ban đầu).
- Zalo giới hạn số tin nhắn OA có thể gửi miễn phí trong khung giờ tương tác với mỗi người dùng (chính sách của Zalo, không phải giới hạn từ code này) — nếu cần gửi ngoài khung giờ đó phải dùng tin nhắn ZNS (trả phí), chưa được tích hợp trong bản này.
- Dữ liệu hiện tại là **thư viện tài sản thương hiệu** (logo/ảnh/catalogue/video/chứng nhận), không phải bảng giá bán lẻ từng SKU. Nếu cần bot tư vấn bán hàng theo giá/SKU, cần bổ sung nguồn dữ liệu đó vào `data.js` hoặc một file riêng.
