// Test nhanh logic cua bot ma KHONG can Zalo OA.
// Chi can co ANTHROPIC_API_KEY trong file .env.
//
// Cach dung:
//   node test.js "cho tôi ảnh sản phẩm CarFresh"
//
// Hoac chay khong tham so de vao che do hoi lien tuc trong terminal:
//   node test.js

require('dotenv').config();
const readline = require('readline');
const { askClaude } = require('./bot-core');

function printResult(result) {
  console.log('\n🤖 ' + result.reply);
  if (result.items && result.items.length) {
    result.items.forEach(it => {
      console.log(`   📁 ${it.name}\n      ${it.link}`);
    });
  }
  console.log('');
}

async function runOnce(question) {
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error('❌ Chưa có ANTHROPIC_API_KEY trong file .env — vào https://console.anthropic.com để lấy key.');
    process.exit(1);
  }
  console.log(`\n👤 ${question}`);
  const result = await askClaude(question, { hotline: process.env.FALLBACK_HOTLINE });
  printResult(result);
}

async function runInteractive() {
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error('❌ Chưa có ANTHROPIC_API_KEY trong file .env — vào https://console.anthropic.com để lấy key.');
    process.exit(1);
  }
  console.log('Chế độ test — gõ câu hỏi rồi Enter (gõ "exit" để thoát):\n');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  rl.setPrompt('👤 ');
  rl.prompt();
  rl.on('line', async (line) => {
    const q = line.trim();
    if (!q) return rl.prompt();
    if (q === 'exit') return rl.close();
    try {
      const result = await askClaude(q, { hotline: process.env.FALLBACK_HOTLINE });
      printResult(result);
    } catch (err) {
      console.error('Lỗi:', err.message);
    }
    rl.prompt();
  });
}

const arg = process.argv.slice(2).join(' ').trim();
if (arg) {
  runOnce(arg).catch(err => { console.error('Lỗi:', err.message); process.exit(1); });
} else {
  runInteractive();
}
